import fs from "node:fs";
import Database from "better-sqlite3";
import { validateStoryBundle } from "@vpf/production-spec";

const [dbPath, projectId, jsonPath] = process.argv.slice(2);
if (!dbPath || !projectId || !jsonPath) {
  console.error("Usage: node validate_t020_neanderthal.mjs <dbPath> <projectId> <jsonPath>");
  process.exit(2);
}

const bundle = JSON.parse(fs.readFileSync(jsonPath, "utf8"));
const db = new Database(dbPath, { readonly: true });
const row = db.prepare(`
  SELECT artifact_json
  FROM agent2_story_audio_artifacts
  WHERE project_id = ?
    AND artifact_type = 'fact_check_spec'
    AND lifecycle_status = 'ACTIVE'
  ORDER BY revision DESC
  LIMIT 1
`).get(projectId);
db.close();

if (!row) {
  console.error(JSON.stringify({ valid:false, errors:[{code:"FACT_CHECK_MISSING",message:"ACTIVE fact_check_spec not found"}]}, null, 2));
  process.exit(1);
}

const facts = JSON.parse(row.artifact_json);
const result = validateStoryBundle(bundle, facts, projectId);
console.log(JSON.stringify(result, null, 2));
process.exit(result.valid ? 0 : 1);
